Zip folder includes:
404 page
Game file page
Home page
Login page
Main game can be found on GameFile.html

About the game:
Game name: Package Party
Target audience: teenagers to young adult
Currently the game features a helicopter that moves up, down, left and right.

features:
- Ui
- Skybox
- 3D model import
- Player interaction with 3D model
